let homePage = require('./home-page')
let staticFiles = require('./static-files')
let faveicon = require('./faveicon')

module.exports = [
    homePage,
    staticFiles,
    faveicon
]