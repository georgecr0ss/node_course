let http = require('http')
let handlers = require('./handlers/index')

let port = 1337

http
  .createServer((req, res) => {
    for (let handler of handlers) {
      let next = handler(req, res)
      if (!next) {
        break // if handler can process url -> stop; else continue with the next handler in the loop
      }
    }
  })
  .listen(port)

console.log(`Node listening on ${port}`)
