let gulp = require('gulp')
let del = require('del')
let uglify = require('gulp-uglify')
let concat = require('gulp-concat')

gulp.task('scripts', function () {
  del.sync(['build/alljs*']) // delete previously created

  return gulp.src([ // files to process
    'content/site.js',
    'content/libs/jquery/dist/jquery.js'
  ])
  .pipe(uglify()) // minify
  .pipe(concat('alljs.min.js')) // concatenate into one file with specified name
  .pipe(gulp.dest('build')) // save into this folder
})

gulp.task('css', function () {
  // define task
})

gulp.task('default', ['scripts', 'css'], function () {})
