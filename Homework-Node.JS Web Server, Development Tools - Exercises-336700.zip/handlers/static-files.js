let fs = require('fs')
let url = require('url')

function getContentType (url) {
  let contentType = 'text/plain' // default
  if (url.endsWith('.css')) {
    contentType = 'text/css'
  } else if (url.endsWith('.js')) {
    contentType = 'application/javascript'
  } else if (url.endsWith('.jpg') || url.endsWith('.jpeg')) {
    contentType = 'image/jpeg'
  } else if (url.endsWith('.png') || url.endsWith('.png')) {
    contentType = 'image/png'
  }
  return contentType
}

function isInPublicFolder (url) {
  let isInPublicFolder = false // default
  if (url.startsWith('/content') || url.startsWith('content')) {
    isInPublicFolder = true
  }
  return isInPublicFolder
}

function isValidType (url) {
  let isValidType = false // default
  if (url.endsWith('.html') || url.endsWith('.css') || url.endsWith('.js') || url.endsWith('.jpg') || url.endsWith('.jpeg')) {
    isValidType = true
  }
  return isValidType
}

module.exports = (req, res) => {
  req.pathName = req.pathName || url.parse(req.url).pathname
  if (isInPublicFolder(req.pathName) && isValidType(req.pathName)) {
    fs.readFile(`.${req.pathName}`, (err, data) => { // url pathname matches the filename
      if (err) {
        res.writeHead(404)
        res.write('404 Not Found')
        res.end()
        return
      }

      let contentType = getContentType(req.pathName)
      res.writeHead(200, {
        'Content-Type': contentType
      })
      res.write(data)
      res.end()
    })
  } else {
    let contentType = getContentType(req.pathName)
    res.writeHead(500, {
      'Content-Type': contentType
    })
    res.write('500 Internal Server Error')
    res.end()
  }
}
