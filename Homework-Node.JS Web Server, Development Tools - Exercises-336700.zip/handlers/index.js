let favicon = require('./favicon')
let homepage = require('./homepage')
let staticFiles = require('./static-files')

module.exports = [
  favicon,
  homepage,
  staticFiles
]
