let fs = require('fs')
let url = require('url')
let formidable = require('formidable')
let util = require('util')

let images = []

function displayForm (res) {
  fs.readFile('./index.html', function (err, data) {
    if (err) console.log(err)
    res.writeHead(200, {
      'Content-Type': 'text/html',
      'Content-Length': data.length
    })
    res.write(data)
    res.end()
  })
}

function processAllFieldsOfTheForm (req, res) {
  var form = new formidable.IncomingForm()

  form.parse(req, function (err, fields, files) {
    // Store the data from the fields in your data store.
    // The data store could be a file or database or any other store based
    // on your application.
    images.push(fields)

    res.writeHead(200, {
      'content-type': 'text/plain'
    })
    res.write('received the data:\n\n')
    res.end(util.inspect({
      fields: fields,
      files: files
    }))
  })
}

function displayImages (res) {
  res.writeHead(200, {
    'Content-Type': 'text/html'
  })
  for (let i = 0; i < images.length; i++){
    let title = images[i].title
    let src = images[i].url
    res.write(`<div><h3>${title}</h3><img src="${src}" alt="${title}" height="100" width="100"></div>`)
  }
  res.end()
}

module.exports = (req, res) => {
  req.pathName = req.pathName || url.parse(req.url).pathname
  if (req.pathName === '/') {
    if (req.method.toLowerCase() === 'get') {
      displayForm(res)
    } else if (req.method.toLowerCase() === 'post') {
      processAllFieldsOfTheForm(req, res)
    }
  } else if (req.pathName === '/images') {
    displayImages(res)
  } else {
    return true
  }
}


//let fs = require('fs')
//let url = require('url')
//
//module.exports = (req, res) => {
//  req.pathName = req.pathName || url.parse(req.url).pathname
//  if (req.pathName === '/') {
//    fs.readFile('./index.html', (err, data) => {
//      if (err) console.log(err)
//      res.writeHead(200, {
//        'Content-Type': 'text/html'
//      })
//      res.write(data)
//      res.end()
//    })
//  } else {
//    return true
//  }
//}
