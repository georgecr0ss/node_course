var a = 1
var b = 15
console.log(a + b)
